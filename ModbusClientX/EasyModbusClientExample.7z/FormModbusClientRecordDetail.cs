﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyModbus;

namespace EasyModbusClientExample
{
    public partial class FormModbusClientRecordDetail : Form
    {
        readonly ModbusData dataObject;
        public FormModbusClientRecordDetail(ModbusData record, ModbusClient c)
        {
            InitializeComponent();
            dataObject = record;
            dataObject.ObjectHasChanged += R_ObjectHasChanged;
            this.propertyGridModbusDetail.SelectedObject = dataObject;
            
            client = c;
        }

        private void R_ObjectHasChanged(object sender, EventArgs e)
        {
            this.btnWrite.Enabled = this.dataObject.HasChanged;
        }

        readonly ModbusClient client;
        private void propertyGridModbusDetail_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            this.propertyGridModbusDetail.Refresh();
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            var o = this.propertyGridModbusDetail.SelectedObject as ModbusData;
            o?.WriteToDevice(client);
        }

        private void FormModbusClientRecordDetail_FormClosing(object sender, FormClosingEventArgs e)
        {
            dataObject.ObjectHasChanged -= R_ObjectHasChanged;
        }
    }

    
}
