﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EasyModbus;

namespace EasyModbusClientExample
{
    public partial class FormConnectionSetting : Form
    {
        public FormConnectionSetting(ModbusTcpClient tcpClient)
        {
            InitializeComponent();
            this.propertyGrid1.SelectedObject = tcpClient;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            var v = this.propertyGrid1.SelectedObject as ModbusTcpClient;
            if (v.Connected)
            {
                v.Disconnect();
            }
            if (v.ConnectionType == ModbusConnectionType.Ethernet)
            {
                v.SerialPort = null;
            }

            else
            {
                if (v.SerialPort == null)
                {
                    throw new Exception("Serial port should not be null");
                }
            }
            v.Connect();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            var client = this.propertyGrid1.SelectedObject as ModbusClient;
            if (radioButtonTCP.Checked)
            {
                client.SerialPort = null;
            }
        }
    }
}
