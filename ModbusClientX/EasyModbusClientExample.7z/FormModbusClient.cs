﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Ports;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows.Forms;
using EasyModbus;
using Newtonsoft.Json;

namespace EasyModbusClientExample
{
    public partial class FormModbusClient : Form
    {
        private readonly List<bool> coils = new List<bool>();

        private bool confirmWrite;

        private MethodInvoker function;
        private readonly StringBuilder logs = new StringBuilder();
        private ModbusTcpClient modbusTcpClient;
        private readonly List<int> registers = new List<int>();


        private int startAddress, numberOfAddress;
        private string values;

        public FormModbusClient()
        {
            InitializeComponent();
            modbusTcpClient = new ModbusTcpClient();

            modbusTcpClient.ReceiveDataChanged += UpdateReceiveData;
            modbusTcpClient.SendDataChanged += UpdateSendData;
            modbusTcpClient.ConnectedChanged += UpdateConnectedChanged;

            InitGrid();
            tabPageEthernet.Select();
            //(cbbParity.SelectedIndex, cbbSelectComPort.SelectedIndex, cbbStopbits.SelectedIndex)
            //    = (0, 0, 0);
            //this.cbbSelectComPort.SelectedIndex = 0;
            //this.cbbParity.SelectedIndex = 0;
            //this.cbbStopbits.SelectedIndex = 0;
            ModbusFunctionChanged(radioReadHoldingRegisters, null);
        }

        private void InitGrid()
        {
            bindingSourceCoil.DataSource = ModbusDataCollectionService.Coils;
            bindingSourceDiscreteInput.DataSource = ModbusDataCollectionService.DiscreteInputs;
            bindingSourceHoldingRegister.DataSource = ModbusDataCollectionService.HoldingRegisters;
            bindingSourceInputRegister.DataSource = ModbusDataCollectionService.InputRegisters;
        }

        private void UpdateReceiveData(object sender)
        {
            var receiveData = "Rx: " + BitConverter.ToString(modbusTcpClient.receiveData).Replace("-", " ") +
                              Environment.NewLine;
            WriteLog(receiveData);
        }

        private void UpdateSendData(object sender)
        {
            var sendData = "Tx: " + BitConverter.ToString(modbusTcpClient.sendData).Replace("-", " ") +
                           Environment.NewLine;
            WriteLog(sendData);
        }

        private void UpdateConnectedChanged(object sender)
        {
            if (modbusTcpClient.Connected)
                lblStatus.Text = "Connected to Server";
            //txtConnectedStatus.BackColor = Color.Green;
            else
                lblStatus.Text = "Not Connected to Server";
        }

        private void ModbusFunctionChanged(object sender, EventArgs e)
        {
            

            values = lblModbusValues.Text = "Values";
            if (sender == radioReadCoil)
            {
                function = ReadCoils;
                TabControlFunction.SelectedTab = tabPageCoil;

                txtModbusValues.Enabled = false;
                txtNumberOfRecords.Enabled = true;
                confirmWrite = false;
            }
            else if (sender == radioReadDiscreteInput)
            {
                function = ReadDiscreteInputs;
                TabControlFunction.SelectedTab = tabPageDiscreteInput;

                txtModbusValues.Enabled = false;
                txtNumberOfRecords.Enabled = true;
                confirmWrite = false;
            }
            else if (sender == radioReadHoldingRegisters)
            {
                function = ReadHoldingRegisters;
                TabControlFunction.SelectedTab = tabPageHoldingRegister;

                txtModbusValues.Enabled = false;
                txtNumberOfRecords.Enabled = true;
                confirmWrite = false;
            }
            else if (sender == radioReadInputRegister)
            {
                function = ReadInputRegisters;
                TabControlFunction.SelectedTab = tabPageInputRegister;

                txtModbusValues.Enabled = false;
                txtNumberOfRecords.Enabled = true;
                confirmWrite = false;
            }
            else if (sender == radioWriteMultipleCoils)
            {
                function = WriteMultipleCoils;
                TabControlFunction.SelectedTab = tabPageCoil;

                lblModbusValues.Text = "Input Coils, separate by commas, 1 for true, 0 for false";
                txtModbusValues.Enabled = true;
                txtNumberOfRecords.Enabled = false;
                confirmWrite = true;
            }
            else if (sender == radioWriteMultipleHoldingRegisters)
            {
                function = WriteMultipleHoldingRegisters;
                TabControlFunction.SelectedTab = tabPageHoldingRegister;

                lblModbusValues.Text = "Input Holding Registers, Number only, separate by commas";
                txtModbusValues.Enabled = true;
                txtNumberOfRecords.Enabled = false;
                confirmWrite = true;
            }
            else if (sender == radioWriteSIngleCoil)
            {
                function = WriteSingleCoil;
                TabControlFunction.SelectedTab = tabPageCoil;

                lblModbusValues.Text = "Input Coil, 1 for true, 0 for false";
                txtModbusValues.Enabled = true;
                txtNumberOfRecords.Enabled = false;
                confirmWrite = true;
            }
            else if (sender == radioWriteSingleHoldingRegister)
            {
                function = WriteSingleHoldingRegister;
                TabControlFunction.SelectedTab = tabPageHoldingRegister;

                lblModbusValues.Text = "Input Holding Registers, Number only";
                txtModbusValues.Enabled = true;
                txtNumberOfRecords.Enabled = false;
                confirmWrite = true;
            }
            else
            {
                confirmWrite = true;
            }
        }
       
        private void ReadCoils()
        {
            ModbusDataCollectionService.ReadCoils(modbusTcpClient, startAddress, numberOfAddress);
        }

        private void ReadDiscreteInputs()
        {
            ModbusDataCollectionService.ReadDiscreteInputs(modbusTcpClient, startAddress, numberOfAddress);
        }

        private void ReadHoldingRegisters()
        {
            ModbusDataCollectionService.ReadHoldingRegisters(modbusTcpClient, startAddress, numberOfAddress);
        }

        private void ReadInputRegisters()
        {
            ModbusDataCollectionService.ReadInputRegisters(modbusTcpClient, startAddress, numberOfAddress);
        }

        private void WriteMultipleCoils()
        {
            PrepareCoils();
            modbusTcpClient.WriteMultipleCoils(startAddress, coils.ToArray());
        }

        private void WriteMultipleHoldingRegisters()
        {
            PrepareRegisters();
            modbusTcpClient.WriteMultipleRegisters(startAddress, registers.ToArray());
        }

        private void WriteSingleCoil()
        {
            PrepareCoils();
            var c = bindingSourceCoil[startAddress] as Coil;
            c.CoilValue = coils[0];
            c.WriteToDevice(modbusTcpClient);
        }

        private void WriteSingleHoldingRegister()
        {
            PrepareRegisters();
            modbusTcpClient.WriteSingleRegister(startAddress, registers[0]);
        }

        private bool PrepareCoils()
        {
            var v = txtModbusValues.Text.Split(char.Parse(","));
            coils.Clear();
            foreach (var item in v)
            {
                int i;
                var r = int.TryParse(item, out i);
                if (r && (i == 0 || i == 1))
                {
                    coils.Add(Convert.ToBoolean(i));
                }
                else
                {
                    MessageBox.Show("Input values NOT valid");
                    WriteLog("Input values NOT valid");
                    return false;
                }
            }

            return true;
        }

        private bool PrepareRegisters()
        {
            var v = txtModbusValues.Text.Split(char.Parse(","));
            registers.Clear();
            foreach (var item in v)
            {
                int i;
                var r = int.TryParse(item, out i);
                if (r == false)
                {
                    MessageBox.Show("Input values NOT valid");
                    WriteLog("Input values NOT valid");
                    return false;
                }

                registers.Add(i);
            }

            return true;
        }


        private void startAddress_TextChanged(object sender, EventArgs e)
        {
            int i;
            var v = int.TryParse(txtStartAddress.Text, out i);
            startAddress = i;

            dataGridViewHoldingRegister.FirstDisplayedScrollingRowIndex = i;
            dataGridViewCoil.FirstDisplayedScrollingRowIndex = i;
            dataGridViewDiscreteInput.FirstDisplayedScrollingRowIndex = i;
            dataGridViewInputRegister.FirstDisplayedScrollingRowIndex = i;
        }

        private void DataGridView_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.ScrollOrientation == ScrollOrientation.VerticalScroll
                && txtStartAddress.Text != e.NewValue.ToString())
                txtStartAddress.Text = e.NewValue.ToString();
        }

        private void txtNumberOfRecords_TextChanged(object sender, EventArgs e)
        {
            int i;
            var v = int.TryParse(txtNumberOfRecords.Text, out i);
            numberOfAddress = i;

            dataGridViewHoldingRegister.Refresh();
        }

        private void tabControlConnection_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if(this.tabControlConnection.SelectedTab == tabPageEthernet)
            //{
            //    this.lblStatus.Text = "Ethernet Connection";
            //}
            //else
            //{
            //    this.lblStatus.Text = "Serial Connection";
            //}
        }

        private void btnSendCommand_Click(object sender, EventArgs e)
        {
            if (confirmWrite)
            {
                var cf = MessageBox.Show("Confirm write to device?", "Confirmation", MessageBoxButtons.OKCancel,
                    MessageBoxIcon.Warning);
                if (cf == DialogResult.Cancel) return;
            }

            try
            {
                //if (modbusTcpClient.Connected)
                //    modbusTcpClient.Disconnect();
                //if (tabControlConnection.SelectedTab == tabPageEthernet)
                //{
                //    modbusTcpClient.IPAddress = txtIpAddressInput.Text;
                //    modbusTcpClient.Port = int.Parse(txtPortInput.Text);
                //    modbusTcpClient.SerialPort = null;
                //    modbusTcpClient.Connect();
                //}
                //else
                //{
                //    modbusTcpClient.SerialPort = cbbSelectComPort.SelectedItem.ToString();

                //    modbusTcpClient.UnitIdentifier = byte.Parse(txtSlaveAddressInput.Text);
                //    modbusTcpClient.Baudrate = int.Parse(txtBaudrate.Text);
                //    if (cbbParity.SelectedIndex == 0)
                //        modbusTcpClient.Parity = Parity.Even;
                //    if (cbbParity.SelectedIndex == 1)
                //        modbusTcpClient.Parity = Parity.Odd;
                //    if (cbbParity.SelectedIndex == 2)
                //        modbusTcpClient.Parity = Parity.None;

                //    if (cbbStopbits.SelectedIndex == 0)
                //        modbusTcpClient.StopBits = StopBits.One;
                //    if (cbbStopbits.SelectedIndex == 1)
                //        modbusTcpClient.StopBits = StopBits.OnePointFive;
                //    if (cbbStopbits.SelectedIndex == 2)
                //        modbusTcpClient.StopBits = StopBits.Two;

                //    modbusTcpClient.Connect();
                

                startAddress = int.Parse(txtStartAddress.Text);
                numberOfAddress = int.Parse(txtNumberOfRecords.Text);
                function.Invoke();
                dataGridViewCoil.Refresh();
                dataGridViewDiscreteInput.Refresh();
                dataGridViewHoldingRegister.Refresh();
                dataGridViewInputRegister.Refresh();
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Unable to connect to Server", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        /// <summary>
        ///     Show the modbus data in property editor
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ModbusDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            var v = sender as DataGridView;
            var obj = v.Rows[e.RowIndex].DataBoundItem as ModbusData;
            var f = new FormModbusClientRecordDetail(obj, modbusTcpClient);
            f.ShowDialog();
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            txtLog.Clear();
            logs.Clear();
        }

        /// <summary>
        ///     log messages to txtLog
        /// </summary>
        /// <param name="log">log message</param>
        private void WriteLog(string log)
        {
            if (txtLog.InvokeRequired)
            {
                var d1 = new writeLogDelegate(wlog);
                d1.Invoke(log);
            }
            else
            {
                wlog(log);
            }

            void wlog(string log)
            {
                var l = "*** " + DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss:ffff") + " ***"
                        + Environment.NewLine
                        + log + Environment.NewLine;
                logs.Insert(0, l);
                txtLog.Text = logs.ToString();
            }
        }

        private void FormModbusClient_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveModbusClientParameters();
        }

        private void SaveModbusClientParameters()
        {
            // Save Setting parameters
            string json = JsonConvert.SerializeObject(modbusTcpClient);
            string path = Application.StartupPath + @"\config.json";
            File.WriteAllText(path, json);
        }
        private void LoadModbusClientParameters()
        {
            // Load Setting parameters
            string path = Application.StartupPath + @"\config.json";
            var json = File.ReadAllText(path);
            JsonConvert.PopulateObject(json, this.modbusTcpClient);
            
        }

        private void FormModbusClient_Load(object sender, EventArgs e)
        {
            LoadModbusClientParameters();
        }

        private void btnConnectionSetting_Click(object sender, EventArgs e)
        {
            FormConnectionSetting f = new FormConnectionSetting(this.modbusTcpClient);
            f.ShowDialog();
        }

        private delegate void writeLogDelegate(string log);
    }
}