﻿namespace EasyModbusClientExample
{
    partial class FormModbusClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.radioWriteMultipleHoldingRegisters = new System.Windows.Forms.RadioButton();
            this.lblModbusValues = new System.Windows.Forms.Label();
            this.txtModbusValues = new System.Windows.Forms.TextBox();
            this.radioWriteMultipleCoils = new System.Windows.Forms.RadioButton();
            this.radioWriteSingleHoldingRegister = new System.Windows.Forms.RadioButton();
            this.radioWriteSIngleCoil = new System.Windows.Forms.RadioButton();
            this.radioReadInputRegister = new System.Windows.Forms.RadioButton();
            this.radioReadHoldingRegisters = new System.Windows.Forms.RadioButton();
            this.radioReadDiscreteInput = new System.Windows.Forms.RadioButton();
            this.radioReadCoil = new System.Windows.Forms.RadioButton();
            this.txtBaudrate = new System.Windows.Forms.TextBox();
            this.lblBaudrate = new System.Windows.Forms.Label();
            this.cbbStopbits = new System.Windows.Forms.ComboBox();
            this.cbbParity = new System.Windows.Forms.ComboBox();
            this.lblStopbits = new System.Windows.Forms.Label();
            this.lblParity = new System.Windows.Forms.Label();
            this.txtSlaveAddressInput = new System.Windows.Forms.TextBox();
            this.txtSlaveAddress = new System.Windows.Forms.Label();
            this.cbbSelectComPort = new System.Windows.Forms.ComboBox();
            this.txtCOMPort = new System.Windows.Forms.Label();
            this.txtPort = new System.Windows.Forms.Label();
            this.txtPortInput = new System.Windows.Forms.TextBox();
            this.txtIpAddress = new System.Windows.Forms.Label();
            this.txtIpAddressInput = new System.Windows.Forms.TextBox();
            this.tabControlConnection = new System.Windows.Forms.TabControl();
            this.tabPageEthernet = new System.Windows.Forms.TabPage();
            this.tabPageSerial = new System.Windows.Forms.TabPage();
            this.dataGridViewHoldingRegister = new System.Windows.Forms.DataGridView();
            this.Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AdressHex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.txtStartAddress = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNumberOfRecords = new System.Windows.Forms.TextBox();
            this.btnSendCommand = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.TabControlFunction = new System.Windows.Forms.TabControl();
            this.tabPageHoldingRegister = new System.Windows.Forms.TabPage();
            this.tabPageInputRegister = new System.Windows.Forms.TabPage();
            this.dataGridViewInputRegister = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCoil = new System.Windows.Forms.TabPage();
            this.dataGridViewCoil = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageDiscreteInput = new System.Windows.Forms.TabPage();
            this.dataGridViewDiscreteInput = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtLog = new System.Windows.Forms.RichTextBox();
            this.btnClearLog = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnConnectionSetting = new System.Windows.Forms.Button();
            this.holdingRegisterDecDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.holdingRegisterBinDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSourceHoldingRegister = new System.Windows.Forms.BindingSource(this.components);
            this.inputRegisterDecDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.inputRegisterBinDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingSourceInputRegister = new System.Windows.Forms.BindingSource(this.components);
            this.coilValueDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bindingSourceCoil = new System.Windows.Forms.BindingSource(this.components);
            this.discreteInputValueDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.bindingSourceDiscreteInput = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox2.SuspendLayout();
            this.tabControlConnection.SuspendLayout();
            this.tabPageEthernet.SuspendLayout();
            this.tabPageSerial.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHoldingRegister)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.TabControlFunction.SuspendLayout();
            this.tabPageHoldingRegister.SuspendLayout();
            this.tabPageInputRegister.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInputRegister)).BeginInit();
            this.tabPageCoil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCoil)).BeginInit();
            this.tabPageDiscreteInput.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDiscreteInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceHoldingRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceInputRegister)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceCoil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceDiscreteInput)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.radioWriteMultipleHoldingRegisters);
            this.groupBox2.Controls.Add(this.lblModbusValues);
            this.groupBox2.Controls.Add(this.txtModbusValues);
            this.groupBox2.Controls.Add(this.radioWriteMultipleCoils);
            this.groupBox2.Controls.Add(this.radioWriteSingleHoldingRegister);
            this.groupBox2.Controls.Add(this.radioWriteSIngleCoil);
            this.groupBox2.Controls.Add(this.radioReadInputRegister);
            this.groupBox2.Controls.Add(this.radioReadHoldingRegisters);
            this.groupBox2.Controls.Add(this.radioReadDiscreteInput);
            this.groupBox2.Controls.Add(this.radioReadCoil);
            this.groupBox2.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(378, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(518, 188);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Modbus Functions";
            // 
            // radioWriteMultipleHoldingRegisters
            // 
            this.radioWriteMultipleHoldingRegisters.AutoSize = true;
            this.radioWriteMultipleHoldingRegisters.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioWriteMultipleHoldingRegisters.Location = new System.Drawing.Point(232, 105);
            this.radioWriteMultipleHoldingRegisters.Name = "radioWriteMultipleHoldingRegisters";
            this.radioWriteMultipleHoldingRegisters.Size = new System.Drawing.Size(282, 21);
            this.radioWriteMultipleHoldingRegisters.TabIndex = 65;
            this.radioWriteMultipleHoldingRegisters.Text = "Write Multiple Holding Registers";
            this.radioWriteMultipleHoldingRegisters.UseVisualStyleBackColor = true;
            this.radioWriteMultipleHoldingRegisters.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioWriteMultipleHoldingRegisters.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // lblModbusValues
            // 
            this.lblModbusValues.Font = new System.Drawing.Font("Courier New", 8F, System.Drawing.FontStyle.Bold);
            this.lblModbusValues.Location = new System.Drawing.Point(14, 139);
            this.lblModbusValues.Name = "lblModbusValues";
            this.lblModbusValues.Size = new System.Drawing.Size(420, 15);
            this.lblModbusValues.TabIndex = 67;
            this.lblModbusValues.Text = "Write Modbus Values";
            // 
            // txtModbusValues
            // 
            this.txtModbusValues.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtModbusValues.Enabled = false;
            this.txtModbusValues.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtModbusValues.Location = new System.Drawing.Point(17, 155);
            this.txtModbusValues.Name = "txtModbusValues";
            this.txtModbusValues.Size = new System.Drawing.Size(484, 22);
            this.txtModbusValues.TabIndex = 66;
            // 
            // radioWriteMultipleCoils
            // 
            this.radioWriteMultipleCoils.AutoSize = true;
            this.radioWriteMultipleCoils.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioWriteMultipleCoils.Location = new System.Drawing.Point(232, 81);
            this.radioWriteMultipleCoils.Name = "radioWriteMultipleCoils";
            this.radioWriteMultipleCoils.Size = new System.Drawing.Size(186, 21);
            this.radioWriteMultipleCoils.TabIndex = 64;
            this.radioWriteMultipleCoils.Text = "Write Multiple Coils";
            this.radioWriteMultipleCoils.UseVisualStyleBackColor = true;
            this.radioWriteMultipleCoils.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioWriteMultipleCoils.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // radioWriteSingleHoldingRegister
            // 
            this.radioWriteSingleHoldingRegister.AutoSize = true;
            this.radioWriteSingleHoldingRegister.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioWriteSingleHoldingRegister.Location = new System.Drawing.Point(232, 57);
            this.radioWriteSingleHoldingRegister.Name = "radioWriteSingleHoldingRegister";
            this.radioWriteSingleHoldingRegister.Size = new System.Drawing.Size(258, 21);
            this.radioWriteSingleHoldingRegister.TabIndex = 63;
            this.radioWriteSingleHoldingRegister.Text = "Write Single Holding Register";
            this.radioWriteSingleHoldingRegister.UseVisualStyleBackColor = true;
            this.radioWriteSingleHoldingRegister.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioWriteSingleHoldingRegister.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // radioWriteSIngleCoil
            // 
            this.radioWriteSIngleCoil.AutoSize = true;
            this.radioWriteSIngleCoil.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioWriteSIngleCoil.Location = new System.Drawing.Point(232, 32);
            this.radioWriteSIngleCoil.Name = "radioWriteSIngleCoil";
            this.radioWriteSIngleCoil.Size = new System.Drawing.Size(162, 21);
            this.radioWriteSIngleCoil.TabIndex = 62;
            this.radioWriteSIngleCoil.Text = "Write Single Coil";
            this.radioWriteSIngleCoil.UseVisualStyleBackColor = true;
            this.radioWriteSIngleCoil.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioWriteSIngleCoil.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // radioReadInputRegister
            // 
            this.radioReadInputRegister.AutoSize = true;
            this.radioReadInputRegister.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioReadInputRegister.Location = new System.Drawing.Point(17, 105);
            this.radioReadInputRegister.Name = "radioReadInputRegister";
            this.radioReadInputRegister.Size = new System.Drawing.Size(186, 21);
            this.radioReadInputRegister.TabIndex = 61;
            this.radioReadInputRegister.Text = "Read Input Registers";
            this.radioReadInputRegister.UseVisualStyleBackColor = true;
            this.radioReadInputRegister.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioReadInputRegister.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // radioReadHoldingRegisters
            // 
            this.radioReadHoldingRegisters.AutoSize = true;
            this.radioReadHoldingRegisters.Checked = true;
            this.radioReadHoldingRegisters.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioReadHoldingRegisters.Location = new System.Drawing.Point(17, 81);
            this.radioReadHoldingRegisters.Name = "radioReadHoldingRegisters";
            this.radioReadHoldingRegisters.Size = new System.Drawing.Size(202, 21);
            this.radioReadHoldingRegisters.TabIndex = 60;
            this.radioReadHoldingRegisters.TabStop = true;
            this.radioReadHoldingRegisters.Text = "Read Holding Registers";
            this.radioReadHoldingRegisters.UseVisualStyleBackColor = true;
            this.radioReadHoldingRegisters.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioReadHoldingRegisters.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // radioReadDiscreteInput
            // 
            this.radioReadDiscreteInput.AutoSize = true;
            this.radioReadDiscreteInput.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioReadDiscreteInput.Location = new System.Drawing.Point(17, 57);
            this.radioReadDiscreteInput.Name = "radioReadDiscreteInput";
            this.radioReadDiscreteInput.Size = new System.Drawing.Size(186, 21);
            this.radioReadDiscreteInput.TabIndex = 59;
            this.radioReadDiscreteInput.Text = "Read Discrete Inputs";
            this.radioReadDiscreteInput.UseVisualStyleBackColor = true;
            this.radioReadDiscreteInput.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioReadDiscreteInput.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // radioReadCoil
            // 
            this.radioReadCoil.AutoSize = true;
            this.radioReadCoil.Font = new System.Drawing.Font("Courier New", 10F);
            this.radioReadCoil.Location = new System.Drawing.Point(17, 32);
            this.radioReadCoil.Name = "radioReadCoil";
            this.radioReadCoil.Size = new System.Drawing.Size(106, 21);
            this.radioReadCoil.TabIndex = 58;
            this.radioReadCoil.Text = "Read Coils";
            this.radioReadCoil.UseVisualStyleBackColor = true;
            this.radioReadCoil.CheckedChanged += new System.EventHandler(this.ModbusFunctionChanged);
            this.radioReadCoil.Click += new System.EventHandler(this.ModbusFunctionChanged);
            // 
            // txtBaudrate
            // 
            this.txtBaudrate.Location = new System.Drawing.Point(34, 104);
            this.txtBaudrate.Name = "txtBaudrate";
            this.txtBaudrate.Size = new System.Drawing.Size(74, 23);
            this.txtBaudrate.TabIndex = 69;
            this.txtBaudrate.Text = "9600";
            // 
            // lblBaudrate
            // 
            this.lblBaudrate.Location = new System.Drawing.Point(31, 82);
            this.lblBaudrate.Name = "lblBaudrate";
            this.lblBaudrate.Size = new System.Drawing.Size(74, 23);
            this.lblBaudrate.TabIndex = 68;
            this.lblBaudrate.Text = "Baudrate";
            // 
            // cbbStopbits
            // 
            this.cbbStopbits.FormattingEnabled = true;
            this.cbbStopbits.Items.AddRange(new object[] {
            "1",
            "1.5",
            "2"});
            this.cbbStopbits.Location = new System.Drawing.Point(219, 103);
            this.cbbStopbits.Name = "cbbStopbits";
            this.cbbStopbits.Size = new System.Drawing.Size(71, 24);
            this.cbbStopbits.TabIndex = 67;
            // 
            // cbbParity
            // 
            this.cbbParity.FormattingEnabled = true;
            this.cbbParity.Items.AddRange(new object[] {
            "Even",
            "Odd",
            "None"});
            this.cbbParity.Location = new System.Drawing.Point(130, 103);
            this.cbbParity.Name = "cbbParity";
            this.cbbParity.Size = new System.Drawing.Size(71, 24);
            this.cbbParity.TabIndex = 66;
            // 
            // lblStopbits
            // 
            this.lblStopbits.Location = new System.Drawing.Point(216, 82);
            this.lblStopbits.Name = "lblStopbits";
            this.lblStopbits.Size = new System.Drawing.Size(74, 23);
            this.lblStopbits.TabIndex = 65;
            this.lblStopbits.Text = "Stopbits";
            // 
            // lblParity
            // 
            this.lblParity.Location = new System.Drawing.Point(126, 82);
            this.lblParity.Name = "lblParity";
            this.lblParity.Size = new System.Drawing.Size(74, 23);
            this.lblParity.TabIndex = 64;
            this.lblParity.Text = "Parity";
            // 
            // txtSlaveAddressInput
            // 
            this.txtSlaveAddressInput.Location = new System.Drawing.Point(218, 43);
            this.txtSlaveAddressInput.Name = "txtSlaveAddressInput";
            this.txtSlaveAddressInput.Size = new System.Drawing.Size(74, 23);
            this.txtSlaveAddressInput.TabIndex = 62;
            this.txtSlaveAddressInput.Text = "1";
            // 
            // txtSlaveAddress
            // 
            this.txtSlaveAddress.Location = new System.Drawing.Point(218, 18);
            this.txtSlaveAddress.Name = "txtSlaveAddress";
            this.txtSlaveAddress.Size = new System.Drawing.Size(99, 17);
            this.txtSlaveAddress.TabIndex = 61;
            this.txtSlaveAddress.Text = "Slave ID";
            this.txtSlaveAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbbSelectComPort
            // 
            this.cbbSelectComPort.FormattingEnabled = true;
            this.cbbSelectComPort.Items.AddRange(new object[] {
            "COM1",
            "COM2",
            "COM3",
            "COM4",
            "COM5",
            "COM6",
            "COM7",
            "COM8"});
            this.cbbSelectComPort.Location = new System.Drawing.Point(34, 39);
            this.cbbSelectComPort.Name = "cbbSelectComPort";
            this.cbbSelectComPort.Size = new System.Drawing.Size(159, 24);
            this.cbbSelectComPort.TabIndex = 60;
            // 
            // txtCOMPort
            // 
            this.txtCOMPort.Location = new System.Drawing.Point(31, 18);
            this.txtCOMPort.Name = "txtCOMPort";
            this.txtCOMPort.Size = new System.Drawing.Size(134, 17);
            this.txtCOMPort.TabIndex = 59;
            this.txtCOMPort.Text = "COM-Port";
            this.txtCOMPort.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(196, 18);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(97, 21);
            this.txtPort.TabIndex = 57;
            this.txtPort.Text = "Server Port";
            // 
            // txtPortInput
            // 
            this.txtPortInput.Location = new System.Drawing.Point(196, 43);
            this.txtPortInput.Name = "txtPortInput";
            this.txtPortInput.Size = new System.Drawing.Size(74, 23);
            this.txtPortInput.TabIndex = 56;
            this.txtPortInput.Text = "502";
            // 
            // txtIpAddress
            // 
            this.txtIpAddress.Location = new System.Drawing.Point(22, 18);
            this.txtIpAddress.Name = "txtIpAddress";
            this.txtIpAddress.Size = new System.Drawing.Size(134, 17);
            this.txtIpAddress.TabIndex = 55;
            this.txtIpAddress.Text = "Server IP-Address";
            // 
            // txtIpAddressInput
            // 
            this.txtIpAddressInput.Location = new System.Drawing.Point(22, 43);
            this.txtIpAddressInput.Name = "txtIpAddressInput";
            this.txtIpAddressInput.Size = new System.Drawing.Size(156, 23);
            this.txtIpAddressInput.TabIndex = 54;
            this.txtIpAddressInput.Text = "127.0.0.1";
            // 
            // tabControlConnection
            // 
            this.tabControlConnection.Controls.Add(this.tabPageEthernet);
            this.tabControlConnection.Controls.Add(this.tabPageSerial);
            this.tabControlConnection.Location = new System.Drawing.Point(16, 15);
            this.tabControlConnection.Name = "tabControlConnection";
            this.tabControlConnection.SelectedIndex = 0;
            this.tabControlConnection.Size = new System.Drawing.Size(342, 173);
            this.tabControlConnection.TabIndex = 2;
            this.tabControlConnection.SelectedIndexChanged += new System.EventHandler(this.tabControlConnection_SelectedIndexChanged);
            // 
            // tabPageEthernet
            // 
            this.tabPageEthernet.Controls.Add(this.btnConnectionSetting);
            this.tabPageEthernet.Controls.Add(this.txtPort);
            this.tabPageEthernet.Controls.Add(this.txtPortInput);
            this.tabPageEthernet.Controls.Add(this.txtIpAddressInput);
            this.tabPageEthernet.Controls.Add(this.txtIpAddress);
            this.tabPageEthernet.Location = new System.Drawing.Point(4, 25);
            this.tabPageEthernet.Name = "tabPageEthernet";
            this.tabPageEthernet.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEthernet.Size = new System.Drawing.Size(334, 144);
            this.tabPageEthernet.TabIndex = 0;
            this.tabPageEthernet.Text = "Ethernet Connection";
            this.tabPageEthernet.UseVisualStyleBackColor = true;
            // 
            // tabPageSerial
            // 
            this.tabPageSerial.Controls.Add(this.txtBaudrate);
            this.tabPageSerial.Controls.Add(this.cbbSelectComPort);
            this.tabPageSerial.Controls.Add(this.lblBaudrate);
            this.tabPageSerial.Controls.Add(this.txtCOMPort);
            this.tabPageSerial.Controls.Add(this.cbbStopbits);
            this.tabPageSerial.Controls.Add(this.txtSlaveAddress);
            this.tabPageSerial.Controls.Add(this.cbbParity);
            this.tabPageSerial.Controls.Add(this.txtSlaveAddressInput);
            this.tabPageSerial.Controls.Add(this.lblStopbits);
            this.tabPageSerial.Controls.Add(this.lblParity);
            this.tabPageSerial.Location = new System.Drawing.Point(4, 25);
            this.tabPageSerial.Name = "tabPageSerial";
            this.tabPageSerial.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageSerial.Size = new System.Drawing.Size(334, 144);
            this.tabPageSerial.TabIndex = 1;
            this.tabPageSerial.Text = "Serial Connection";
            this.tabPageSerial.UseVisualStyleBackColor = true;
            // 
            // dataGridViewHoldingRegister
            // 
            this.dataGridViewHoldingRegister.AllowUserToAddRows = false;
            this.dataGridViewHoldingRegister.AllowUserToDeleteRows = false;
            this.dataGridViewHoldingRegister.AutoGenerateColumns = false;
            this.dataGridViewHoldingRegister.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridViewHoldingRegister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewHoldingRegister.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Address,
            this.AdressHex,
            this.holdingRegisterDecDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn1,
            this.holdingRegisterBinDataGridViewTextBoxColumn});
            this.dataGridViewHoldingRegister.DataSource = this.bindingSourceHoldingRegister;
            this.dataGridViewHoldingRegister.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewHoldingRegister.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewHoldingRegister.Name = "dataGridViewHoldingRegister";
            this.dataGridViewHoldingRegister.ReadOnly = true;
            this.dataGridViewHoldingRegister.Size = new System.Drawing.Size(541, 185);
            this.dataGridViewHoldingRegister.TabIndex = 3;
            this.dataGridViewHoldingRegister.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ModbusDataGridView_CellDoubleClick);
            this.dataGridViewHoldingRegister.Scroll += new System.Windows.Forms.ScrollEventHandler(this.DataGridView_Scroll);
            // 
            // Address
            // 
            this.Address.DataPropertyName = "Address";
            this.Address.HeaderText = "Address";
            this.Address.Name = "Address";
            this.Address.ReadOnly = true;
            this.Address.Width = 89;
            // 
            // AdressHex
            // 
            this.AdressHex.DataPropertyName = "AdressHex";
            this.AdressHex.HeaderText = "Adress (Hex)";
            this.AdressHex.Name = "AdressHex";
            this.AdressHex.ReadOnly = true;
            this.AdressHex.Width = 82;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(19, 195);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 21);
            this.label1.TabIndex = 59;
            this.label1.Text = "Start address";
            // 
            // txtStartAddress
            // 
            this.txtStartAddress.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStartAddress.Location = new System.Drawing.Point(19, 216);
            this.txtStartAddress.Name = "txtStartAddress";
            this.txtStartAddress.Size = new System.Drawing.Size(124, 22);
            this.txtStartAddress.TabIndex = 58;
            this.txtStartAddress.Text = "1";
            this.txtStartAddress.TextChanged += new System.EventHandler(this.startAddress_TextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(183, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 21);
            this.label2.TabIndex = 61;
            this.label2.Text = "Number of records";
            // 
            // txtNumberOfRecords
            // 
            this.txtNumberOfRecords.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumberOfRecords.Location = new System.Drawing.Point(183, 216);
            this.txtNumberOfRecords.Name = "txtNumberOfRecords";
            this.txtNumberOfRecords.Size = new System.Drawing.Size(167, 22);
            this.txtNumberOfRecords.TabIndex = 60;
            this.txtNumberOfRecords.Text = "10";
            this.txtNumberOfRecords.TextChanged += new System.EventHandler(this.txtNumberOfRecords_TextChanged);
            // 
            // btnSendCommand
            // 
            this.btnSendCommand.Font = new System.Drawing.Font("Courier New", 10F);
            this.btnSendCommand.Location = new System.Drawing.Point(378, 213);
            this.btnSendCommand.Name = "btnSendCommand";
            this.btnSendCommand.Size = new System.Drawing.Size(193, 29);
            this.btnSendCommand.TabIndex = 62;
            this.btnSendCommand.Text = "Send Cmd to Device";
            this.btnSendCommand.UseVisualStyleBackColor = true;
            this.btnSendCommand.Click += new System.EventHandler(this.btnSendCommand_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblStatus});
            this.statusStrip1.Location = new System.Drawing.Point(0, 467);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 18, 0);
            this.statusStrip1.Size = new System.Drawing.Size(914, 22);
            this.statusStrip1.TabIndex = 63;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblStatus
            // 
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(16, 17);
            this.lblStatus.Text = "...";
            // 
            // TabControlFunction
            // 
            this.TabControlFunction.Controls.Add(this.tabPageHoldingRegister);
            this.TabControlFunction.Controls.Add(this.tabPageInputRegister);
            this.TabControlFunction.Controls.Add(this.tabPageCoil);
            this.TabControlFunction.Controls.Add(this.tabPageDiscreteInput);
            this.TabControlFunction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabControlFunction.Location = new System.Drawing.Point(0, 0);
            this.TabControlFunction.Name = "TabControlFunction";
            this.TabControlFunction.SelectedIndex = 0;
            this.TabControlFunction.Size = new System.Drawing.Size(555, 220);
            this.TabControlFunction.TabIndex = 64;
            // 
            // tabPageHoldingRegister
            // 
            this.tabPageHoldingRegister.Controls.Add(this.dataGridViewHoldingRegister);
            this.tabPageHoldingRegister.Location = new System.Drawing.Point(4, 25);
            this.tabPageHoldingRegister.Name = "tabPageHoldingRegister";
            this.tabPageHoldingRegister.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageHoldingRegister.Size = new System.Drawing.Size(547, 191);
            this.tabPageHoldingRegister.TabIndex = 0;
            this.tabPageHoldingRegister.Text = "Holding Register";
            this.tabPageHoldingRegister.UseVisualStyleBackColor = true;
            // 
            // tabPageInputRegister
            // 
            this.tabPageInputRegister.Controls.Add(this.dataGridViewInputRegister);
            this.tabPageInputRegister.Location = new System.Drawing.Point(4, 25);
            this.tabPageInputRegister.Name = "tabPageInputRegister";
            this.tabPageInputRegister.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageInputRegister.Size = new System.Drawing.Size(547, 191);
            this.tabPageInputRegister.TabIndex = 1;
            this.tabPageInputRegister.Text = "Input Register";
            this.tabPageInputRegister.UseVisualStyleBackColor = true;
            // 
            // dataGridViewInputRegister
            // 
            this.dataGridViewInputRegister.AllowUserToAddRows = false;
            this.dataGridViewInputRegister.AllowUserToDeleteRows = false;
            this.dataGridViewInputRegister.AutoGenerateColumns = false;
            this.dataGridViewInputRegister.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridViewInputRegister.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewInputRegister.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn5,
            this.inputRegisterDecDataGridViewTextBoxColumn,
            this.dataGridViewTextBoxColumn6,
            this.inputRegisterBinDataGridViewTextBoxColumn});
            this.dataGridViewInputRegister.DataSource = this.bindingSourceInputRegister;
            this.dataGridViewInputRegister.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewInputRegister.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewInputRegister.Name = "dataGridViewInputRegister";
            this.dataGridViewInputRegister.ReadOnly = true;
            this.dataGridViewInputRegister.Size = new System.Drawing.Size(541, 188);
            this.dataGridViewInputRegister.TabIndex = 4;
            this.dataGridViewInputRegister.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ModbusDataGridView_CellDoubleClick);
            this.dataGridViewInputRegister.Scroll += new System.Windows.Forms.ScrollEventHandler(this.DataGridView_Scroll);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn3.HeaderText = "Address";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "AdressHex";
            this.dataGridViewTextBoxColumn5.HeaderText = "Adress (Hex)";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // tabPageCoil
            // 
            this.tabPageCoil.Controls.Add(this.dataGridViewCoil);
            this.tabPageCoil.Location = new System.Drawing.Point(4, 25);
            this.tabPageCoil.Name = "tabPageCoil";
            this.tabPageCoil.Size = new System.Drawing.Size(547, 191);
            this.tabPageCoil.TabIndex = 2;
            this.tabPageCoil.Text = "Coil";
            this.tabPageCoil.UseVisualStyleBackColor = true;
            // 
            // dataGridViewCoil
            // 
            this.dataGridViewCoil.AllowUserToAddRows = false;
            this.dataGridViewCoil.AllowUserToDeleteRows = false;
            this.dataGridViewCoil.AutoGenerateColumns = false;
            this.dataGridViewCoil.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridViewCoil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCoil.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn10,
            this.coilValueDataGridViewCheckBoxColumn});
            this.dataGridViewCoil.DataSource = this.bindingSourceCoil;
            this.dataGridViewCoil.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCoil.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewCoil.Name = "dataGridViewCoil";
            this.dataGridViewCoil.ReadOnly = true;
            this.dataGridViewCoil.Size = new System.Drawing.Size(547, 194);
            this.dataGridViewCoil.TabIndex = 4;
            this.dataGridViewCoil.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ModbusDataGridView_CellDoubleClick);
            this.dataGridViewCoil.Scroll += new System.Windows.Forms.ScrollEventHandler(this.DataGridView_Scroll);
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn8.HeaderText = "Address";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "AdressHex";
            this.dataGridViewTextBoxColumn10.HeaderText = "Adress (Hex)";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // tabPageDiscreteInput
            // 
            this.tabPageDiscreteInput.Controls.Add(this.dataGridViewDiscreteInput);
            this.tabPageDiscreteInput.Location = new System.Drawing.Point(4, 25);
            this.tabPageDiscreteInput.Name = "tabPageDiscreteInput";
            this.tabPageDiscreteInput.Size = new System.Drawing.Size(547, 191);
            this.tabPageDiscreteInput.TabIndex = 3;
            this.tabPageDiscreteInput.Text = "Discrete Input";
            this.tabPageDiscreteInput.UseVisualStyleBackColor = true;
            // 
            // dataGridViewDiscreteInput
            // 
            this.dataGridViewDiscreteInput.AllowUserToAddRows = false;
            this.dataGridViewDiscreteInput.AllowUserToDeleteRows = false;
            this.dataGridViewDiscreteInput.AutoGenerateColumns = false;
            this.dataGridViewDiscreteInput.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dataGridViewDiscreteInput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDiscreteInput.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.discreteInputValueDataGridViewCheckBoxColumn});
            this.dataGridViewDiscreteInput.DataSource = this.bindingSourceDiscreteInput;
            this.dataGridViewDiscreteInput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewDiscreteInput.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewDiscreteInput.Name = "dataGridViewDiscreteInput";
            this.dataGridViewDiscreteInput.ReadOnly = true;
            this.dataGridViewDiscreteInput.Size = new System.Drawing.Size(547, 194);
            this.dataGridViewDiscreteInput.TabIndex = 4;
            this.dataGridViewDiscreteInput.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ModbusDataGridView_CellDoubleClick);
            this.dataGridViewDiscreteInput.Scroll += new System.Windows.Forms.ScrollEventHandler(this.DataGridView_Scroll);
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn11.HeaderText = "Address";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "AdressHex";
            this.dataGridViewTextBoxColumn12.HeaderText = "Adress (Hex)";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // txtLog
            // 
            this.txtLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLog.Location = new System.Drawing.Point(3, 3);
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.Size = new System.Drawing.Size(324, 214);
            this.txtLog.TabIndex = 65;
            this.txtLog.Text = "";
            // 
            // btnClearLog
            // 
            this.btnClearLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearLog.Location = new System.Drawing.Point(803, 213);
            this.btnClearLog.Name = "btnClearLog";
            this.btnClearLog.Size = new System.Drawing.Size(99, 29);
            this.btnClearLog.TabIndex = 68;
            this.btnClearLog.Text = "Clear Log";
            this.btnClearLog.UseVisualStyleBackColor = true;
            this.btnClearLog.Click += new System.EventHandler(this.btnClearLog_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(16, 244);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.TabControlFunction);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.txtLog);
            this.splitContainer1.Size = new System.Drawing.Size(886, 220);
            this.splitContainer1.SplitterDistance = 555;
            this.splitContainer1.TabIndex = 69;
            // 
            // btnConnectionSetting
            // 
            this.btnConnectionSetting.Location = new System.Drawing.Point(25, 80);
            this.btnConnectionSetting.Name = "btnConnectionSetting";
            this.btnConnectionSetting.Size = new System.Drawing.Size(245, 23);
            this.btnConnectionSetting.TabIndex = 58;
            this.btnConnectionSetting.Text = "Connection Setting";
            this.btnConnectionSetting.UseVisualStyleBackColor = true;
            this.btnConnectionSetting.Click += new System.EventHandler(this.btnConnectionSetting_Click);
            // 
            // holdingRegisterDecDataGridViewTextBoxColumn
            // 
            this.holdingRegisterDecDataGridViewTextBoxColumn.DataPropertyName = "HoldingRegisterDec";
            this.holdingRegisterDecDataGridViewTextBoxColumn.HeaderText = "Holding Register";
            this.holdingRegisterDecDataGridViewTextBoxColumn.Name = "holdingRegisterDecDataGridViewTextBoxColumn";
            this.holdingRegisterDecDataGridViewTextBoxColumn.ReadOnly = true;
            this.holdingRegisterDecDataGridViewTextBoxColumn.Width = 147;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "HoldingRegisterHex";
            this.dataGridViewTextBoxColumn1.HeaderText = "Holding Register (Hex)";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 132;
            // 
            // holdingRegisterBinDataGridViewTextBoxColumn
            // 
            this.holdingRegisterBinDataGridViewTextBoxColumn.DataPropertyName = "HoldingRegisterBin";
            this.holdingRegisterBinDataGridViewTextBoxColumn.HeaderText = "Holding Register (Binary)";
            this.holdingRegisterBinDataGridViewTextBoxColumn.Name = "holdingRegisterBinDataGridViewTextBoxColumn";
            this.holdingRegisterBinDataGridViewTextBoxColumn.ReadOnly = true;
            this.holdingRegisterBinDataGridViewTextBoxColumn.Width = 154;
            // 
            // bindingSourceHoldingRegister
            // 
            this.bindingSourceHoldingRegister.AllowNew = false;
            this.bindingSourceHoldingRegister.DataSource = typeof(EasyModbusClientExample.HoldingRegister);
            // 
            // inputRegisterDecDataGridViewTextBoxColumn
            // 
            this.inputRegisterDecDataGridViewTextBoxColumn.DataPropertyName = "InputRegisterDec";
            this.inputRegisterDecDataGridViewTextBoxColumn.HeaderText = "Input Register";
            this.inputRegisterDecDataGridViewTextBoxColumn.Name = "inputRegisterDecDataGridViewTextBoxColumn";
            this.inputRegisterDecDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "InputRegisterHex";
            this.dataGridViewTextBoxColumn6.HeaderText = "Input Register (Hex)";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // inputRegisterBinDataGridViewTextBoxColumn
            // 
            this.inputRegisterBinDataGridViewTextBoxColumn.DataPropertyName = "InputRegisterBin";
            this.inputRegisterBinDataGridViewTextBoxColumn.HeaderText = "Input Register (Binary)";
            this.inputRegisterBinDataGridViewTextBoxColumn.Name = "inputRegisterBinDataGridViewTextBoxColumn";
            this.inputRegisterBinDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // bindingSourceInputRegister
            // 
            this.bindingSourceInputRegister.AllowNew = false;
            this.bindingSourceInputRegister.DataSource = typeof(EasyModbusClientExample.InputRegister);
            // 
            // coilValueDataGridViewCheckBoxColumn
            // 
            this.coilValueDataGridViewCheckBoxColumn.DataPropertyName = "CoilValue";
            this.coilValueDataGridViewCheckBoxColumn.HeaderText = "CoilValue";
            this.coilValueDataGridViewCheckBoxColumn.Name = "coilValueDataGridViewCheckBoxColumn";
            this.coilValueDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // bindingSourceCoil
            // 
            this.bindingSourceCoil.AllowNew = false;
            this.bindingSourceCoil.DataSource = typeof(EasyModbusClientExample.Coil);
            // 
            // discreteInputValueDataGridViewCheckBoxColumn
            // 
            this.discreteInputValueDataGridViewCheckBoxColumn.DataPropertyName = "DiscreteInputValue";
            this.discreteInputValueDataGridViewCheckBoxColumn.HeaderText = "Discrete Input";
            this.discreteInputValueDataGridViewCheckBoxColumn.Name = "discreteInputValueDataGridViewCheckBoxColumn";
            this.discreteInputValueDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // bindingSourceDiscreteInput
            // 
            this.bindingSourceDiscreteInput.AllowNew = false;
            this.bindingSourceDiscreteInput.DataSource = typeof(EasyModbusClientExample.DiscreteInput);
            // 
            // FormModbusClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(914, 489);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.btnClearLog);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.btnSendCommand);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNumberOfRecords);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtStartAddress);
            this.Controls.Add(this.tabControlConnection);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Courier New", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FormModbusClient";
            this.Text = "Modbus Client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormModbusClient_FormClosing);
            this.Load += new System.EventHandler(this.FormModbusClient_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControlConnection.ResumeLayout(false);
            this.tabPageEthernet.ResumeLayout(false);
            this.tabPageEthernet.PerformLayout();
            this.tabPageSerial.ResumeLayout(false);
            this.tabPageSerial.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewHoldingRegister)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.TabControlFunction.ResumeLayout(false);
            this.tabPageHoldingRegister.ResumeLayout(false);
            this.tabPageInputRegister.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewInputRegister)).EndInit();
            this.tabPageCoil.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCoil)).EndInit();
            this.tabPageDiscreteInput.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDiscreteInput)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceHoldingRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceInputRegister)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceCoil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourceDiscreteInput)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtBaudrate;
        private System.Windows.Forms.Label lblBaudrate;
        private System.Windows.Forms.ComboBox cbbStopbits;
        private System.Windows.Forms.ComboBox cbbParity;
        private System.Windows.Forms.Label lblStopbits;
        private System.Windows.Forms.Label lblParity;
        private System.Windows.Forms.TextBox txtSlaveAddressInput;
        private System.Windows.Forms.Label txtSlaveAddress;
        private System.Windows.Forms.ComboBox cbbSelectComPort;
        private System.Windows.Forms.Label txtCOMPort;
        private System.Windows.Forms.Label txtPort;
        private System.Windows.Forms.TextBox txtPortInput;
        private System.Windows.Forms.Label txtIpAddress;
        private System.Windows.Forms.TextBox txtIpAddressInput;
        private System.Windows.Forms.TabControl tabControlConnection;
        private System.Windows.Forms.TabPage tabPageEthernet;
        private System.Windows.Forms.TabPage tabPageSerial;
        private System.Windows.Forms.RadioButton radioWriteMultipleHoldingRegisters;
        private System.Windows.Forms.RadioButton radioWriteMultipleCoils;
        private System.Windows.Forms.RadioButton radioWriteSingleHoldingRegister;
        private System.Windows.Forms.RadioButton radioWriteSIngleCoil;
        private System.Windows.Forms.RadioButton radioReadInputRegister;
        private System.Windows.Forms.RadioButton radioReadHoldingRegisters;
        private System.Windows.Forms.RadioButton radioReadDiscreteInput;
        private System.Windows.Forms.RadioButton radioReadCoil;
        private System.Windows.Forms.DataGridView dataGridViewHoldingRegister;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtStartAddress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNumberOfRecords;
        private System.Windows.Forms.Button btnSendCommand;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblStatus;
        private System.Windows.Forms.TabControl TabControlFunction;
        private System.Windows.Forms.TabPage tabPageHoldingRegister;
        private System.Windows.Forms.TabPage tabPageInputRegister;
        private System.Windows.Forms.BindingSource bindingSourceHoldingRegister;
        private System.Windows.Forms.BindingSource bindingSourceCoil;
        private System.Windows.Forms.BindingSource bindingSourceInputRegister;
        private System.Windows.Forms.BindingSource bindingSourceDiscreteInput;
        private System.Windows.Forms.TabPage tabPageCoil;
        private System.Windows.Forms.TabPage tabPageDiscreteInput;
        private System.Windows.Forms.DataGridView dataGridViewInputRegister;
        private System.Windows.Forms.DataGridView dataGridViewCoil;
        private System.Windows.Forms.DataGridView dataGridViewDiscreteInput;
        private System.Windows.Forms.RichTextBox txtLog;
        private System.Windows.Forms.TextBox txtModbusValues;
        private System.Windows.Forms.Label lblModbusValues;
        private System.Windows.Forms.Button btnClearLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn AdressHex;
        private System.Windows.Forms.DataGridViewTextBoxColumn holdingRegisterDecDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn holdingRegisterBinDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn inputRegisterDecDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn inputRegisterBinDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewCheckBoxColumn coilValueDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewCheckBoxColumn discreteInputValueDataGridViewCheckBoxColumn;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button btnConnectionSetting;
    }
}